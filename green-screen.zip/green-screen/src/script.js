var fgimage=null;
var bgimage=null;
var tex;
var text;
function upload(){
  var file =document.getElementById("can");
  tex = document.getElementById("oput1");
  fgimage = new SimpleImage(text);
  fgimage.drawTo(tex);
}
function upload1(){
  var file =document.getElementById("canvas");
  text=document.getElementById("oput2");
  bgimage = new SimpleImage(text);
  bgimage.drawTo(tex);
}
function clearcanvas() {
  doClear(tex);
  doClear(text);
}

function doClear(canvas) {
  var context = canvas.getContext("2d");
  context.clearRect(0,0,canvas.width,canvas.height);
}
